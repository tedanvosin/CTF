<?php if ($admin){
		include_once "admin.php";
	} else{
		include_once "user.php";
	}
?>
